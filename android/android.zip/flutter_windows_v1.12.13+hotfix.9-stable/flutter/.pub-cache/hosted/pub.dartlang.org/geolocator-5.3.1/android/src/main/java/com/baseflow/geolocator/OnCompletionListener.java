package com.baseflow.geolocator;

import java.util.UUID;

public interface OnCompletionListener {
    void onCompletion(UUID taskID);
}